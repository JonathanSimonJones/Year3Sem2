#include "..\\HeaderFiles\\Triangle.h"

Triangle::Triangle():
	m_FX(0),
	m_Technique(0),
	m_VertexLayout(0)
{
}